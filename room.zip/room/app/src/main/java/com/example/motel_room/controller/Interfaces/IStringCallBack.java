package com.example.motel_room.controller.Interfaces;

public interface IStringCallBack {
    public void sendString(String value);
}
