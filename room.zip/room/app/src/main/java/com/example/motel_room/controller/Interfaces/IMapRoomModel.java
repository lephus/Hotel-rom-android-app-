package com.example.motel_room.controller.Interfaces;

import com.example.motel_room.model.RoomModel;

public interface IMapRoomModel {
    public void getListLocationRoom(RoomModel valueRoom);
}
