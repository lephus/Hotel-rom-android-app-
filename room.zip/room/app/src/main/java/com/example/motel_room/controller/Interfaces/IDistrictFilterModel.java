package com.example.motel_room.controller.Interfaces;

public interface IDistrictFilterModel {
    public void sendDistrict(String District);
}
