package com.example.motel_room.controller.Interfaces;

import com.example.motel_room.model.UserModel;

public interface IFindRoomAddModel {
    public void getUserModel(UserModel valueUserModel);
}

