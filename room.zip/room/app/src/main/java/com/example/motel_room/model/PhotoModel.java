package com.example.motel_room.model;

public class PhotoModel {
    private int resourceId;

    public PhotoModel(int resourceId) {
        this.resourceId = resourceId;
    }

    public int getResourceId() {
        return resourceId;
    }

    public void setResourceId(int resourceId) {
        this.resourceId = resourceId;
    }
}
