package com.example.motel_room.controller.Interfaces;

public interface OnPostRoomFinish {
    public void invoke();
}
