package com.example.motel_room.controller.Interfaces;

import com.example.motel_room.model.RoomModel;

public interface IUpdateRoomModel {
    public void getSuccessNotifyRoomMode1(RoomModel roomModel);
}
