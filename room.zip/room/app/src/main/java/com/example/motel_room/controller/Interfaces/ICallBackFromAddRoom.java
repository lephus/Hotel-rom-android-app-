package com.example.motel_room.controller.Interfaces;

public interface ICallBackFromAddRoom {
    public void stopProgess(boolean isSuccess);
}
