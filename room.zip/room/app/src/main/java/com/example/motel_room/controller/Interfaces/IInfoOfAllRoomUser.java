package com.example.motel_room.controller.Interfaces;

public interface IInfoOfAllRoomUser {
    public void sendQuantity(int value,int type);
}
