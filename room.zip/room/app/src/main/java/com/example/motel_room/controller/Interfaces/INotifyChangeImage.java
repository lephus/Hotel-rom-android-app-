package com.example.motel_room.controller.Interfaces;

import java.util.List;

public interface INotifyChangeImage {
    public void isNotifyChange(List<String> listImagePath);
}
