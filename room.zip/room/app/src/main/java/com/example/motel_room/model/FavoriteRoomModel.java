package com.example.motel_room.model;

public class FavoriteRoomModel {
    String roomId, time;

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public FavoriteRoomModel() {

    }
}
