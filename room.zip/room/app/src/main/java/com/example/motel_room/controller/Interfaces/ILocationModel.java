package com.example.motel_room.controller.Interfaces;

import com.example.motel_room.model.LocationModel;

import java.util.List;

public interface ILocationModel {
    public void getListTopRoom(List<LocationModel> topLocation);
}
